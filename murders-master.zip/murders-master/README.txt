We analyze US gun murder data collected by the FBI.

download-data.R - downloads csv file to data directory

wrangle-data.R - creates a derived dataset and saves as R object in rdas directory

analysis.R - makes the 

A plot is generated and saved in the figs directory.