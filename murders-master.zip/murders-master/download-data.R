url <- "https://raw.githubusercontent.com/rafalab/dslabs/master/inst/extdata/murders.csv"
destination_file <- "data/murders.csv"
download.file(url, destination_file)
